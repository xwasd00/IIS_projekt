<li class="navbar-btn"><a href="{{route('student')}}">Zaregistrované testy</a></li>
<li class="navbar-btn"><a href="{{route('student.reg')}}">Registrace testů</a></li>
<li class="navbar-btn"><a href="{{route('student.eval')}}">Hodnocení testů</a></li>
