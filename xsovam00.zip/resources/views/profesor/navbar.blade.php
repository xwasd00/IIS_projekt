<li class="navbar-btn"><a href="{{route('profesor')}}">Všechny testy</a></li>
<li class="navbar-btn"><a href="{{route('profesor.addtest')}}">Vytvoření testů</a></li>
<li class="navbar-btn"><a href="{{route('profesor.mytests')}}">Moje testy</a></li>
