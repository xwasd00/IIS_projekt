<li class="navbar-btn"><a href="{{route('asistent')}}">Registrace žáků</a></li>
<li class="navbar-btn"><a href="{{route('asistent.eval')}}">Hodnocení žáků</a></li>